import { EstudianteModel } from './estudiante.model';

// Refleja CiudadDTO.
export interface CiudadModel {
  idCiudad: number;
  nombre: string;
  departamento: string;
}

// Refleja UniversidadDTO (GET /api/catalogos/universidades).
export interface UniversidadModel {
  idUniversidad: number;
  nombre: string;
  sigla: string;
  calle: string;
  barrio: string;
  ciudad: CiudadModel | null;
}

// Universidad + cuántos estudiantes tiene y una vista previa. El backend no entrega
// conteos, así que se calculan en el front cruzando universidades con el catálogo de usuarios.
export interface UniversidadResumenModel extends UniversidadModel {
  cantidad: number;
  vistaPrevia: EstudianteModel[];
}

// Resultado de la pantalla de universidades. totalEstudiantes cuenta personas distintas
// (un estudiante con carreras en dos universidades aparece en ambas, pero se cuenta una vez).
export interface ResumenUniversidadesModel {
  universidades: UniversidadResumenModel[];
  totalEstudiantes: number;
}
